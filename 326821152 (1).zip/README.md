# Computing and Numerics - Assignment A2 [50 marks]

The assignment and instructions are in `A2.ipynb`.

The marking scheme is outlined in `A2_mark_scheme.pdf`.
